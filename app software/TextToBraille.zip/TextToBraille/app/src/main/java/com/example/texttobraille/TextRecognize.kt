package com.example.texttobraille

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

// this code is from https://developers.google.com/ml-kit/vision/text-recognition/v2/android#1_create_an_instance_of_textrecognizer
fun recognizeTextFromBitmap(
    bitmap: Bitmap,
    onResult: (String) -> Unit,
    onError: (Exception) -> Unit
) {
    val image = InputImage.fromBitmap(bitmap, 0)
    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    recognizer.process(image)
        .addOnSuccessListener { visionText ->
            onResult(visionText.text)
        }
        .addOnFailureListener { e ->
            onError(e)
        }
}
