package com.example.texttobraille

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var resultTextView: TextView


    // bluetooth communication important variables:
    private var bluetoothSocket: BluetoothSocket? = null
    private var outputStream: OutputStream? = null
    private var inputStream: InputStream? = null

    private val deviceAddress = "E8:6B:EA:D3:4B:F6"// here is my ESP32 address, you should change it for your own esp's


    // SPP UUID, very common - probably will work for your esp too
    private val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private fun checkBluetoothPermission(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
                ),
                1
            )
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION
                ),
                1
            )
        }
    }

    // All Bluetooth communication functions:

    // this handles ending connection with ESP32 in case of an unexpected error
    override fun onDestroy() {
        super.onDestroy()
        ESP32disconnect()
    }

    // this function ends Android client connection with ESP32
    // by closing all I/O streams and resetting socket
    private fun ESP32disconnect() {
        try {
            inputStream?.close()
            outputStream?.close()
            bluetoothSocket?.close()
            bluetoothSocket = null

            Toast.makeText(this, "Disconnected ❌", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "ERROR: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // this function take all text from TextView field and
    // passes it to ESP32 as an input via Bluetooth
    private fun sendTextToESP32(){
        if(outputStream == null){
            Toast.makeText(this, "Bluetooth not connected", Toast.LENGTH_SHORT).show()
            return
        }
        val textToSend = resultTextView.text.toString().trim()
        if (textToSend.isNotEmpty() && textToSend != getString(R.string.textview_info)) {
            outputStream?.write((textToSend + "\n").toByteArray())
            runOnUiThread {
                Toast.makeText(this, "Sent ✅", Toast.LENGTH_SHORT).show()
            }
        } else {
            runOnUiThread {
                Toast.makeText(this, "Input empty", Toast.LENGTH_SHORT).show()
            }
        }
    }


    // this function:
    // checks for any other open sockets, after previous client, and closes it
    // creates new Bluetooth Adapter for communication
    // search for an ESP32 and creates new connection with the client
    private fun ESP32connect(){
        bluetoothSocket?.let {
            try { it.close() } catch(e: Exception) {}
            bluetoothSocket = null
        }

        val adapter = BluetoothAdapter.getDefaultAdapter()
        if(adapter == null){
            runOnUiThread {
                Toast.makeText(this, "Bluetooth not supported", Toast.LENGTH_SHORT).show()
            }
            return
        }

        if (!adapter.isEnabled) {
            try {
                val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                startActivity(enableBtIntent)
                Toast.makeText(this, "Bluetooth not enabled", Toast.LENGTH_SHORT).show()
            } catch (se: SecurityException) {
                Toast.makeText(this, "Bluetooth permission denied", Toast.LENGTH_SHORT).show()
            }
            return
        }


        Thread {
            try {
                val device = adapter.getRemoteDevice(deviceAddress)
                try {
                    adapter.cancelDiscovery()
                } catch (se: SecurityException) {
                    runOnUiThread {
                        Toast.makeText(this, "Bluetooth permission denied", Toast.LENGTH_SHORT).show()
                    }
                }

                // fallback RFCOMM - stable connection
                bluetoothSocket = try {
                    device.createRfcommSocketToServiceRecord(uuid)
                } catch(e: IOException) {
                    val m = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                    m.invoke(device, 1) as BluetoothSocket
                }

                Thread.sleep(500) // give it a moment to stable

                bluetoothSocket?.connect()  // now it should work

                outputStream = bluetoothSocket?.outputStream
                inputStream = bluetoothSocket?.inputStream

                // quick test if connection works
//                outputStream?.write("-Bluetooth connected successfully-\n".toByteArray())

                runOnUiThread {
                    Toast.makeText(this, "Connected to ESP32 ✅", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "ERROR: ${e.message}", Toast.LENGTH_SHORT).show()
                }
                ESP32disconnect()
            }
        }.start()
    }


    private val getCameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isgranted ->
            if (!isgranted) {
                Toast.makeText(this, "Camera access must be given first", Toast.LENGTH_SHORT).show()
            }
            else {
                runCameraApp.launch(null)
            }
        }

    val runCameraApp =
        registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
            if (bitmap != null) {
                recognizeTextFromBitmap(
                    bitmap,
                    onResult = { text -> resultTextView.text = text },
                    onError = { error -> resultTextView.text = "ERROR: ${error.message}" }
                )
            }
        }

    // main function - it first checks needed permissions
    // and then handles the application functionalities
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        checkBluetoothPermission()

        // initiate text view (this big, white field where your scanned text is visible)
        resultTextView = findViewById(R.id.resultTextView)


        val btnTakePhoto = findViewById<Button>(R.id.btnTakePhoto)
        btnTakePhoto.setOnClickListener {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) != PackageManager.PERMISSION_GRANTED
            ) {
//              you need camera permission in order to take a photo
                getCameraPermission.launch(Manifest.permission.CAMERA)
            }
            else {
//              other way - just open camera app
                runCameraApp.launch(null)
            }
        }

        val btnBTconnect = findViewById<Button>(R.id.btnBTconnect)
        btnBTconnect.setOnClickListener {
            ESP32connect()
        }

        val btnBTdisconnect = findViewById<Button>(R.id.btnBTdisconnect)
        btnBTdisconnect.setOnClickListener {
            ESP32disconnect()
        }

        val btnSend = findViewById<Button>(R.id.btnSend)
        btnSend.setOnClickListener {
            sendTextToESP32()
        }
    }
}